@include('site.layouts.head')
  @yield('content')
@include('site.layouts.foot')
